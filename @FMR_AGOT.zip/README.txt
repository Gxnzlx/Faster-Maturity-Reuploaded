# AGOT Compatch – Temporary Fix

This repository provides a temporary fix for the AGOT Compatch.

## Installation

1. Subscribe to the AGOT Compatch: https://steamcommunity.com/sharedfiles/filedetails/?id=3339322970
2. Navigate to the mod's Workshop folder: steamapps\workshop\content\1158310\3339322970

3. Delete the existing "common" and "events" folders.
4. Extract the common and events folders from the "@FMR_AGOT" ZIP into the compatch folder.
5. Launch the game.

## Notes

This is a temporary fix. It may be replaced by an official update once the issue has been addressed by the original author.
version="*"
tags={
	"Events"
}
name="[AGOT] Faster Maturity Compatibility Patch"
supported_version="1.*.*.*"
remote_file_id="3339322970"